# Mantém WebView JS interfaces se forem adicionadas no futuro
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
